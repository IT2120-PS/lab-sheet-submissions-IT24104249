setwd("C:\\Users\\it24104249\\Desktop\\IT24104249")



#1. Import the dataset (’Exercise.txt’) into R and store it in a data frame called ”branch data”.

branch_data <- read.table("C:\\Users\\it24104249\\Downloads\\Exercise.txt", header = TRUE, sep = ",")
View(branch_data)

fix(branch_data)
attach(branch_data)


#2. 
str(branch_data)




#3
boxplot(Sales_X1 ,
        main = "Box Plot For Scales" ,
        ylab = "Sales" ,
        outline = TRUE , 
        outpch = 8 ,
        horizintal = TRUE )



#4. 

quantile(Advertising_X2)


#5. 

get.outliers <- function(z){
  q1 <- quantile(z)[2]; q3 <- quantile(z)[4]; iqr <- q3 -q1
  lb <- q1 - 1.5*iqr; ub <- q3 + 105*iqr
  print(paste("Upper Bound = " , ub))
  print(paste("Lower Bound = " , lb))
  print(paste("outliers : ", paste(sort(z[z < lb | z > lb]) , collapse = " , ") ))
}

get.outliers(Years_X3)
