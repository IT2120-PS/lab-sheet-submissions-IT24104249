setwd("C:\\Users\\Arosha Induma\\OneDrive\\Desktop\\PS lab06\\IT24104249")
# Binomial distribution with n = 50, p = 0.85

# P(X ≥ 47) = 1 - P(X ≤ 46)
pbinom(46, 50, 0.85, lower.tail = FALSE)

# X = number of calls per hour
# Distribution: Poisson
# Parameter: λ = 12

# Poisson distribution with lambda = 12

dpois(15, 12)
