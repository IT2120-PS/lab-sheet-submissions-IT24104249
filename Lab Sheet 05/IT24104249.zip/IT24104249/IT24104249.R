setwd("C:\\Users\\Arosha Induma\\OneDrive\\Desktop\\IT24104249")


Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(Delivery_Times)

fix(Delivery_Times)
names(Delivery_Times) <- c("x1")
attach(Delivery_Times)

#Part 2
#Using "breaks" command we can define number of classes we need in the histogram
#along with lower limit and upper limit.
#Using "right" command we can define whether classes have closed intervals or open intervals.
breaks <- seq(20, 70, length.out = 10)

histogram = hist(x1, main = "Histogram for Number of Shareholders", breaks = breaks ,right = FALSE)

#Check how each argument inside "hist" command works using "help" command as follows
?hist

#The histogram shows a right-skewed distribution, 
#indicating that most delivery times are on the lower end, with a few longer deliveries.
 

# Create frequency table
freq_table <- hist(x1, breaks = breaks, plot = FALSE)

# Calculate cumulative frequencies
cum_freq <- cumsum(freq_table$counts)

# Plot ogive
plot(freq_table$breaks[-1], cum_freq, 
     type = "o", 
     main = "Cumulative Frequency Polygon (Ogive)", 
     xlab = "Delivery Time", 
     ylab = "Cumulative Frequency", 
     col = "darkgreen", 
     pch = 16)
