setwd("C:\\Users\\Arosha Induma\\OneDrive\\Desktop\\PS lab 07\\IT24104249")
#  1: Uniform Distribution ---
# Train arrives between 8:00 and 8:40 → 0 to 0.667 hours
start <- 0
end <- 40 / 60  # 0.667 hours
lower_bound <- 10 / 60  # 8:10 a.m.
upper_bound <- 25 / 60  # 8:25 a.m.

uniform_prob <- (upper_bound - lower_bound) / (end - start)
cat("Probability (Uniform):", uniform_prob, "\n")

# --2: Exponential Distribution ---
# x = 1/3, time ≤ 2 hours
x <- 1 / 3
time <- 2

exp_prob <- 1 - exp(-x * time)
cat("Probability (Exponential ≤ 2 hrs):", exp_prob, "\n")

# --3(i): Normal Distribution ---
# IQ > 130, mean = 100, sd = 15
mean_iq <- 100
sd_iq <- 15
threshold <- 130

prob_above_130 <- 1 - pnorm(threshold, mean = mean_iq, sd = sd_iq)
cat("Probability (IQ > 130):", prob_above_130, "\n")

# --3(ii): 95th Percentile IQ ---
percentile <- 0.95
iq_95th <- qnorm(percentile, mean = mean_iq, sd = sd_iq)
cat("95th Percentile IQ Score:", iq_95th, "\n")
